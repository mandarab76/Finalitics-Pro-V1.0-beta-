
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { GoogleGenAI, Type, Chat, GenerateContentResponse } from "@google/genai";
import { AnalysisResult } from "../types";

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    companyName: {
      type: Type.STRING,
      description: "The identified name of the analyzed entity.",
    },
    summary: {
      type: Type.STRING,
      description: "A professional executive summary.",
    },
    metrics: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          value: { type: Type.NUMBER },
          unit: { type: Type.STRING },
          trend: { type: Type.STRING, enum: ['up', 'down', 'neutral'] },
          description: { type: Type.STRING },
        },
        required: ["label", "value", "unit", "trend", "description"],
      },
    },
    ratios: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING, enum: ['Liquidity', 'Profitability', 'Solvency', 'Efficiency'] },
          name: { type: Type.STRING },
          value: { type: Type.NUMBER },
          formula: { type: Type.STRING },
          interpretation: { type: Type.STRING },
          benchmark: { type: Type.STRING },
        },
        required: ["category", "name", "value", "formula", "interpretation"],
      },
    },
    trends: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          period: { type: Type.STRING },
          revenue: { type: Type.NUMBER },
          expenses: { type: Type.NUMBER },
          margin: { type: Type.NUMBER },
        },
        required: ["period", "revenue", "expenses", "margin"],
      },
    },
    riskAssessment: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING },
          level: { type: Type.STRING, enum: ['low', 'medium', 'high'] },
          score: { type: Type.NUMBER },
          mitigation: { type: Type.STRING },
        },
        required: ["category", "level", "score", "mitigation"],
      },
    },
    forecasts: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          period: { type: Type.STRING },
          projected: { type: Type.NUMBER },
          confidence: { type: Type.ARRAY, items: { type: Type.NUMBER } },
        },
        required: ["period", "projected", "confidence"],
      },
    },
    peerBenchmarking: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          metric: { type: Type.STRING },
          companyValue: { type: Type.NUMBER },
          industryAverage: { type: Type.NUMBER },
        },
        required: ["metric", "companyValue", "industryAverage"],
      },
    },
    liquidityRunwayMonths: {
      type: Type.NUMBER,
      description: "Months of cash runway.",
    },
    insights: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    rawFormulas: {
      type: Type.STRING,
    },
  },
  required: [
    "companyName", "summary", "metrics", "ratios", "insights", "rawFormulas", 
    "trends", "riskAssessment", "forecasts", "peerBenchmarking", "liquidityRunwayMonths"
  ],
};

export const analyzeFinancialData = async (
  context: string,
  onStreamUpdate: (text: string) => void,
  fileData?: { data: string, mimeType: string },
  dateRange?: { start: string, end: string }
): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const systemInstruction = `
    You are the Lead Financial Architect at ATSintegrated. Your mission is precision-led intelligence extraction.
    
    UNIT AUTONOMY PROTOCOL (MANDATORY):
    - The user provides raw ledger strings, statements, or company names.
    - You MUST identify the input units (Crores, Lakhs, Billions, Trillions).
    - DO NOT require the user to perform any conversion.
    - Internally CONVERT all monetary figures to Millions of Indian Rupees (₹ Million).
    - Rule: 1 Crore = 10 Million. 1 Lakh = 0.1 Million. $1 Billion = ₹83,000 Million (approx).
    - Every "value" in your JSON output must be a number representing ₹ Millions.
    - Labels must be professional and standardized.
    
    IDENTITY & SEARCH:
    - Accurately identify the entity. If a ticker like "RELIANCE" is provided, use Google Search to get their latest audited metrics for the selected window: ${dateRange ? `${dateRange.start} to ${dateRange.end}` : "Current FY"}.
    
    AESTHETICS:
    - Provide deep strategic reasoning for the matrix detail modal (explanation and implication).
    
    Return VALID JSON only.
  `;

  const parts: any[] = [{ text: `Perform a deep-vector architectural audit of this context. Ensure all outputs are normalized to ₹ Millions:\n\n${context}` }];
  if (fileData) {
    parts.push({ inlineData: { data: fileData.data, mimeType: fileData.mimeType } });
  }

  try {
    const streamResult = await ai.models.generateContentStream({
      model: "gemini-3-pro-preview",
      contents: { parts },
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        tools: [{ googleSearch: {} }],
      },
    });

    let fullText = "";
    let groundingChunks: any[] = [];

    for await (const chunk of streamResult) {
      const response = chunk as GenerateContentResponse;
      fullText += response.text || "";
      const metadata = response.candidates?.[0]?.groundingMetadata;
      if (metadata?.groundingChunks) {
        groundingChunks = metadata.groundingChunks;
      }
      onStreamUpdate(fullText);
    }

    const result = JSON.parse(fullText) as AnalysisResult;

    if (groundingChunks && groundingChunks.length > 0) {
      result.groundingSources = groundingChunks
        .map((chunk: any) => chunk.web)
        .filter((web: any) => web && web.uri);
    }

    return result;
  } catch (error) {
    console.error("Core Engine Failure:", error);
    throw error;
  }
};

export const createFinancialChat = (financialContext: string): Chat => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: `
        You are Finu, the ATSintegrated Assistant. Use this context: ${financialContext}.
        Provide expert professional context for user inquiries.
      `,
    },
  });
};
