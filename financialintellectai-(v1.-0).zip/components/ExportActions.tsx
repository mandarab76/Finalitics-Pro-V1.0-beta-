
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState } from 'react';
import { AnalysisResult } from '../types';
import saveAs from 'file-saver';
import JSZip from 'jszip';

interface Props {
  data: AnalysisResult | null;
}

export const ExportActions: React.FC<Props> = ({ data }) => {
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  if (!data) return null;

  const exportCSV = () => {
    let csvContent = "Category,Label,Value,Unit,Trend,Description\n";
    data.metrics.forEach(m => {
      csvContent += `Metric,${m.label},${m.value},${m.unit},${m.trend},"${m.description}"\n`;
    });
    csvContent += "\nRatio Name,Category,Value,Formula,Interpretation\n";
    data.ratios.forEach(r => {
      csvContent += `${r.name},${r.category},${r.value},"${r.formula}","${r.interpretation}"\n`;
    });
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    saveAs(blob, `ATSintegrated_Analysis_${data.companyName}_${new Date().toISOString().split('T')[0]}.csv`);
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // INSTITUTIONAL PROJECT BUNDLER (GITHUB & VERCEL READY)
  const bundleProjectSource = async () => {
    setIsZipping(true);
    const zip = new JSZip();

    try {
      // 1. The Core Application
      zip.file("index.html", document.documentElement.outerHTML);
      
      // 2. High-Fidelity README.md reflecting the Corporate Philosophy
      const readmeContent = `# ATSintegrated | Redefining Solutions Delivery

![ATSintegrated Logo](https://raw.githubusercontent.com/mandarab76/ATSIntegrated/main/logo.png)

## Institutional Mission
ATSintegrated is an alpha-grade Enterprise Financial Intelligence & Audit Platform. Developed for high-stakes institutional decision-making, it eliminates manual normalization and provides a precision-led architectural audit of complex financial data.

### Core Philosophy
We believe in **Redefining Solutions Delivery** through:
- **Autonomous Intelligence**: Direct conversion of raw ledger strings (Crores/Lakhs/USD) into normalized ₹ Million metrics without user intervention.
- **Institutional Secrecy**: Adherence to the "Secret Sauce" doctrine. Specific intelligence sources are attributed via a microscopic *Sources* footnote to protect proprietary lineage while maintaining legal compliance.
- **Architectural Auditing**: Moving beyond simple charts to provide strategic implications and executive context for every data node.

## Key Features
- **Dynamic Intelligence Port**: Auto-normalized KPI badges with drag-and-drop prioritization.
- **Revenue Velocity Modeling**: High-fidelity trajectory forecasting using Gemini 3 Pro.
- **Proprietary Risk Vectors**: 100-point risk scoring with mitigation strategies.
- **Finu Intellect Assistant**: Context-aware AI agent for deep-dive analytical queries.
- **Cyber-Glass UI**: A professional aesthetic designed for industry stalwarts, prioritizing clarity and institutional prestige.

## Technical Architecture
- **Engine**: Google Gemini 3 Pro (Generative AI Reasoning)
- **Framework**: React 19 (ESM Architecture)
- **Styling**: Tailwind CSS with Cyber-Glass Backdrop Blurs
- **Visualization**: Recharts (Professional Vector Graphics)

## Deployment (Vercel Protocol)
1. **Initialize**: Create a new repository on GitHub.
2. **Push**: Upload the contents of this bundle.
3. **Connect**: Link your GitHub repository to [Vercel](https://vercel.com).
4. **Environment**: Add \`API_KEY\` to your Vercel Environment Variables.
5. **Launch**: Deploy with zero-config for an instant, secure, globally distributed endpoint.

---
© ${new Date().getFullYear()} ATSintegrated. Developed by Mandar Bahadarpurkar.
*Proprietary Intelligence Shield Active.*`;

      zip.file("README.md", readmeContent);
      
      // 3. Deployment Configuration
      zip.file("vercel.json", JSON.stringify({
        "version": 2,
        "framework": "vite",
        "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
      }, null, 2));

      // 4. Deployment Check-list
      zip.file("DEPLOY_INSTRUCTIONS.txt", "1. Create GitHub Repo.\n2. Upload these files.\n3. In Vercel, set API_KEY env variable.\n4. Share the Vercel URL with your network.");

      const content = await zip.generateAsync({ type: "blob" });
      saveAs(content, `ATSintegrated_Enterprise_Bundle.zip`);
    } catch (err) {
      console.error("Bundling Error:", err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-3 no-print">
      <button 
        onClick={bundleProjectSource}
        disabled={isZipping}
        title="Generate institutional source bundle for GitHub/Vercel"
        className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg border border-amber-400/30 bg-amber-400/10 text-amber-400 hover:bg-amber-400 hover:text-black ${isZipping ? 'animate-pulse' : ''}`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
        {isZipping ? 'Packaging Source...' : 'Bundle Source'}
      </button>

      <div className="h-6 w-px bg-white/10 mx-1" />

      <button 
        onClick={handleShare}
        className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-sm border ${
          copied ? 'bg-emerald-500 border-emerald-400 text-white' : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:border-indigo-500'
        }`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>
        {copied ? 'Link Copied' : 'Share Link'}
      </button>

      <button 
        onClick={exportCSV}
        className="flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 text-slate-400 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:border-indigo-500 hover:text-white transition-all shadow-sm"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        CSV
      </button>

      <button 
        onClick={() => window.print()}
        className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
        PDF Report
      </button>
    </div>
  );
};
