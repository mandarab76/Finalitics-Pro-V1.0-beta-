
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { RiskFactor } from '../types';

interface Props {
  risks: RiskFactor[];
  onSelect?: (risk: RiskFactor) => void;
}

export const RiskMeter: React.FC<Props> = ({ risks, onSelect }) => {
  return (
    <div className="glass-panel p-8 rounded-[40px] border-white/5 shadow-xl">
      <h3 className="text-[10px] font-black text-rose-400 uppercase tracking-[0.2em] mb-8">Risk Matrix Assessment</h3>
      <div className="space-y-8">
        {risks.map((risk, idx) => (
          <div 
            key={idx} 
            className="group cursor-pointer hover:bg-white/5 p-4 -m-4 rounded-[24px] transition-all duration-300"
            onClick={() => onSelect?.(risk)}
          >
            <div className="flex justify-between items-end mb-3">
              <div>
                <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{risk.category}</span>
              </div>
              <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded ${
                risk.level === 'high' ? 'text-rose-400 bg-rose-400/10' : 
                risk.level === 'medium' ? 'text-amber-400 bg-amber-400/10' : 'text-indigo-400 bg-indigo-400/10'
              }`}>
                {risk.level} Severity
              </span>
            </div>
            <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/5 shadow-inner">
              <div 
                className={`h-full transition-all duration-1000 ease-[cubic-bezier(0.19,1,0.22,1)] rounded-full ${
                  risk.level === 'high' ? 'bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.4)]' : 
                  risk.level === 'medium' ? 'bg-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.4)]' : 
                  'bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.4)]'
                }`}
                style={{ width: `${risk.score}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
