
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { PeerBenchmark as PeerType } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, CartesianGrid } from 'recharts';

interface Props {
  benchmarks: PeerType[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#0f172a]/95 backdrop-blur-xl border border-white/10 p-4 rounded-2xl shadow-2xl">
        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">{label}</p>
        <div className="space-y-2">
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex justify-between items-center gap-4">
              <span className="text-[10px] font-bold text-slate-400 uppercase">{entry.name}</span>
              <span className={`text-xs font-black ${entry.name === 'You' ? 'text-indigo-400' : 'text-slate-200'}`}>
                {entry.value.toFixed(1)}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  }
  return null;
};

export const PeerBenchmark: React.FC<Props> = ({ benchmarks }) => {
  const data = benchmarks.map(b => ({
    name: b.metric,
    You: b.companyValue,
    Industry: b.industryAverage
  }));

  return (
    <div className="glass-panel p-8 rounded-[40px] border-white/5 shadow-xl h-full flex flex-col">
      <h3 className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] mb-6">Peer Benchmarking</h3>
      <div className="flex-1 min-h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 0, left: -20, bottom: 0 }} barGap={6}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.03)" />
            <XAxis 
              dataKey="name" 
              fontSize={9} 
              tickLine={false} 
              axisLine={false} 
              stroke="#64748b"
              tick={{ fontWeight: 700 }}
            />
            <YAxis 
              fontSize={9} 
              tickLine={false} 
              axisLine={false} 
              stroke="#64748b"
              tick={{ fontWeight: 700 }}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)', radius: 4 }} />
            <Legend 
              verticalAlign="top" 
              align="right" 
              iconType="circle" 
              wrapperStyle={{ fontSize: '9px', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', paddingBottom: '20px' }} 
            />
            <Bar 
              dataKey="You" 
              fill="#6366f1" 
              radius={[6, 6, 0, 0]} 
              barSize={16} 
              animationDuration={1500}
            />
            <Bar 
              dataKey="Industry" 
              fill="#334155" 
              radius={[6, 6, 0, 0]} 
              barSize={16} 
              animationDuration={2000}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
