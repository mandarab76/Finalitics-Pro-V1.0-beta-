
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Brush } from 'recharts';
import { TrendData, ForecastPoint } from '../types';

interface Props {
  trends: TrendData[];
  forecasts: ForecastPoint[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#0f172a]/95 backdrop-blur-xl border border-white/10 p-5 rounded-3xl shadow-2xl min-w-[200px]">
        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] mb-3">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex justify-between items-center gap-6 mb-1 last:mb-0">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{entry.name}</span>
            <span className="text-sm font-black text-white">₹{entry.value.toLocaleString()} M</span>
          </div>
        ))}
        <div className="mt-3 pt-3 border-t border-white/5">
          <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">
            {payload[0].payload.type === 'forecast' ? 'Synthetic Projection' : 'Audited Reality'}
          </p>
        </div>
      </div>
    );
  }
  return null;
};

export const TrendChart: React.FC<Props> = ({ trends, forecasts }) => {
  const combinedData = [
    ...trends.map(t => ({ ...t, type: 'actual' })),
    ...forecasts.map(f => ({ period: f.period, revenue: f.projected, type: 'forecast' }))
  ];

  const pivotPoint = trends[trends.length - 1]?.period;

  return (
    <div className="w-full h-full p-6 sm:p-10 glass-panel rounded-[48px] border-white/5 shadow-2xl flex flex-col">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-10">
        <div>
          <h3 className="text-[11px] font-black text-indigo-400 uppercase tracking-[0.3em]">Revenue Velocity Modeling</h3>
          <p className="text-xs text-slate-500 font-bold mt-2">Historical vs Projected Trajectory (Scale: ₹ Million)</p>
        </div>
        <div className="flex gap-6 no-print">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.6)]" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Realized</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-indigo-500/30 border border-indigo-500/50" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Synthetic</span>
          </div>
        </div>
      </div>
      
      <div className="flex-1 min-h-0">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={combinedData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorGlow" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.03)" />
            <XAxis 
              dataKey="period" 
              stroke="#475569" 
              fontSize={10} 
              tickLine={false} 
              axisLine={false} 
              dy={15}
              tick={{ fontWeight: 600 }}
            />
            <YAxis 
              stroke="#475569" 
              fontSize={10} 
              tickLine={false} 
              axisLine={false} 
              tickFormatter={(val) => `₹${val >= 1000 ? (val/1000).toFixed(1) + 'B' : val + 'M'}`}
              tick={{ fontWeight: 600 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine 
              x={pivotPoint} 
              stroke="#fbbf24" 
              strokeDasharray="5 5" 
              label={{ value: 'Audit Pivot', position: 'top', fill: '#fbbf24', fontSize: 10, fontWeight: 800, textAnchor: 'middle' }}
            />
            <Area 
              name="Revenue"
              type="monotone" 
              dataKey="revenue" 
              stroke="#6366f1" 
              fillOpacity={1} 
              fill="url(#colorGlow)" 
              strokeWidth={4} 
              connectNulls 
              animationDuration={2000} 
              activeDot={{ r: 8, strokeWidth: 0, fill: '#6366f1' }}
            />
            <Brush 
              dataKey="period" 
              height={30} 
              stroke="#1e293b" 
              fill="#0f172a"
              className="no-print"
              travellerWidth={10}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
