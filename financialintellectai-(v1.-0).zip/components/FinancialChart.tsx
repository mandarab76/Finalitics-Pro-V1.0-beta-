
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { FinancialRatio } from '../types';

interface Props {
  ratios: FinancialRatio[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-[#0f172a]/95 backdrop-blur-xl border border-white/10 p-5 rounded-2xl shadow-2xl">
        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">{data.category}</p>
        <p className="text-sm font-bold text-white mb-2">{label}</p>
        <div className="flex items-center gap-3">
          <span className="text-2xl font-black text-white">{data.value.toFixed(2)}</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase">Index</span>
        </div>
      </div>
    );
  }
  return null;
};

export const FinancialChart: React.FC<Props> = ({ ratios }) => {
  const data = ratios.map(r => ({
    name: r.name,
    value: r.value,
    category: r.category
  }));

  return (
    <div className="w-full h-full p-2 sm:p-6">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart 
          data={data} 
          layout="vertical" 
          margin={{ left: 40, right: 30, top: 20, bottom: 20 }}
          barGap={10}
        >
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="rgba(255,255,255,0.03)" />
          <XAxis 
            type="number" 
            stroke="#475569" 
            fontSize={10} 
            axisLine={false} 
            tickLine={false}
            tickFormatter={(val) => val.toFixed(1)}
          />
          <YAxis 
            dataKey="name" 
            type="category" 
            stroke="#94a3b8" 
            fontSize={10} 
            width={140} 
            axisLine={false} 
            tickLine={false}
            tick={{ fontWeight: 600 }}
          />
          <Tooltip 
            content={<CustomTooltip />}
            cursor={{ fill: 'rgba(99, 102, 241, 0.05)', radius: 8 }}
          />
          <Bar 
            dataKey="value" 
            radius={[0, 12, 12, 0]} 
            barSize={24}
            animationDuration={1500}
          >
            {data.map((entry, index) => {
              let fillColor = '#6366f1'; // Default Indigo
              if (entry.category === 'Profitability') fillColor = '#10b981'; // Emerald
              if (entry.category === 'Liquidity') fillColor = '#fbbf24'; // Gold/Amber
              if (entry.category === 'Solvency') fillColor = '#8b5cf6'; // Violet
              
              return (
                <Cell 
                  key={`cell-${index}`} 
                  fill={fillColor} 
                  fillOpacity={0.8}
                  className="hover:fill-opacity-100 transition-all duration-300"
                />
              );
            })}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
