
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';

interface MatrixDetail {
  title: string;
  value: string | number;
  unit?: string;
  category?: string;
  explanation: string;
  implication: string;
}

interface Props {
  detail: MatrixDetail | null;
  onClose: () => void;
}

export const MatrixDetailModal: React.FC<Props> = ({ detail, onClose }) => {
  if (!detail) return null;

  return (
    <div 
      className="fixed inset-0 z-[150] flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-300"
      onClick={onClose}
    >
      <div 
        className="glass-panel w-full max-w-2xl max-h-[90vh] rounded-[40px] sm:rounded-[48px] p-8 sm:p-12 relative border-white/10 shadow-2xl animate-in zoom-in-95 duration-500 overflow-y-auto custom-scrollbar"
        onClick={e => e.stopPropagation()}
      >
        {/* Glow Backgrounds */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-600/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-violet-600/10 rounded-full blur-[100px] pointer-events-none" />

        <button 
          onClick={onClose}
          className="absolute top-6 right-6 w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center bg-white/5 text-white/40 hover:text-white rounded-full transition-all border border-white/5 z-10"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>

        <div className="relative space-y-6 sm:space-y-8">
          <div className="space-y-2">
            <span className="text-[9px] font-black text-indigo-400 uppercase tracking-[0.4em] block">Intelligence Node</span>
            <h3 className="text-3xl sm:text-4xl font-black text-white tracking-tighter pr-8">{detail.title}</h3>
            {detail.category && (
              <span className="inline-block px-3 py-1 bg-white/5 border border-white/10 rounded-lg text-[9px] font-black text-slate-400 uppercase tracking-widest mt-2">
                {detail.category}
              </span>
            )}
          </div>

          <div className="flex items-baseline gap-2 sm:gap-3 flex-wrap">
            <span className="text-5xl sm:text-7xl font-black text-white tracking-tighter leading-none">{detail.value}</span>
            <span className="text-lg sm:text-xl font-bold text-indigo-400">{detail.unit}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-10 pt-4 border-t border-white/5">
            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Contextual Definition</h4>
              <p className="text-slate-300 leading-relaxed text-sm sm:text-base font-medium">{detail.explanation}</p>
            </div>
            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.2em]">Strategic Implication</h4>
              <p className="text-slate-300 leading-relaxed text-sm sm:text-base font-medium italic border-l-2 border-emerald-500/30 pl-4">
                {detail.implication}
              </p>
            </div>
          </div>
          
          <div className="pt-6">
             <button 
               onClick={onClose}
               className="w-full py-4 bg-white/5 hover:bg-white/10 text-white font-black uppercase tracking-widest text-[10px] rounded-2xl transition-all border border-white/5"
             >
               Close Analysis
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};
