/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useRef, useEffect } from 'react';
import { Chat, GenerateContentResponse } from "@google/genai";
import { createFinancialChat } from '../services/geminiService';
import { ChatMessage } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  context: string;
}

export const ChatBot: React.FC<Props> = ({ isOpen, onClose, context }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showFinuPrompt, setShowFinuPrompt] = useState(false);
  const chatRef = useRef<Chat | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && !chatRef.current) {
      chatRef.current = createFinancialChat(context);
    }
  }, [isOpen, context]);

  useEffect(() => {
    const timer = setTimeout(() => setShowFinuPrompt(true), 2500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping || !chatRef.current) return;

    const userMsg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const result = await chatRef.current.sendMessageStream({ message: userMsg });
      let fullResponse = "";
      setMessages(prev => [...prev, { role: 'model', text: "" }]);
      for await (const chunk of result) {
        const c = chunk as GenerateContentResponse;
        fullResponse += c.text || "";
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1].text = fullResponse;
          return updated;
        });
      }
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', text: "Finu encountered a data anomaly. Retry in T-minus 5." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <>
      <div className={`fixed bottom-8 right-8 z-[100] flex flex-col items-end pointer-events-none transition-all duration-700 ${isOpen ? 'opacity-0 scale-90 translate-y-20' : 'opacity-100'}`}>
        {showFinuPrompt && !isOpen && (
          <div className="relative mb-6 mr-2 bg-indigo-600 text-white px-7 py-5 rounded-[28px] rounded-br-lg shadow-[0_20px_50px_rgba(79,70,229,0.5)] pointer-events-auto animate-in fade-in slide-in-from-right-4 duration-500 max-w-[280px] border border-white/20 group/prompt">
            <button 
              onClick={(e) => { e.stopPropagation(); setShowFinuPrompt(false); }}
              className="absolute -top-3 -right-3 w-8 h-8 bg-slate-900 text-white rounded-full flex items-center justify-center border border-white/20 hover:bg-rose-500 transition-colors shadow-2xl"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <p className="text-[14px] font-bold leading-relaxed tracking-tight">
              Hi, I am <span className="underline decoration-2 decoration-indigo-300">Finu</span>, your AI buddy. Need expert context?
            </p>
          </div>
        )}
        
        <button onClick={onClose} className="w-16 h-16 relative pointer-events-auto group no-print transform hover:scale-110 active:scale-95 transition-all">
          <div className="absolute inset-0 bg-indigo-600 rounded-[22px] rotate-45 shadow-[0_0_40px_rgba(79,70,229,0.6)] group-hover:rotate-[55deg] transition-all duration-700" />
          <div className="absolute inset-0 bg-white/10 rounded-[20px] rotate-12 scale-90 blur-xl animate-pulse" />
          <div className="absolute inset-0 flex items-center justify-center">
             <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
          </div>
        </button>
      </div>

      <div className={`fixed inset-y-0 right-0 w-full md:w-[500px] bg-slate-900/95 backdrop-blur-3xl border-l border-white/10 z-[110] transform transition-transform duration-1000 ease-[cubic-bezier(0.19,1,0.22,1)] ${isOpen ? 'translate-x-0 shadow-[-50px_0_100px_rgba(0,0,0,0.5)]' : 'translate-x-full'} flex flex-col`}>
        <div className="h-24 flex-none flex items-center justify-between px-10 border-b border-white/5 bg-black/20">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600 rounded-[18px] flex items-center justify-center text-white font-black text-xl rotate-12 shadow-xl shadow-indigo-900/50">F</div>
            <div>
              <h3 className="text-lg font-black text-white tracking-tight leading-none">Finu Intellect</h3>
              <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mt-1">Autonomous Financial Agent</p>
            </div>
          </div>
          <button onClick={() => onClose()} className="w-12 h-12 flex items-center justify-center bg-white/5 text-white/40 hover:text-rose-400 rounded-full transition-all hover:bg-white/10">
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-8 custom-scrollbar">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
              <div className="w-20 h-20 bg-indigo-500/10 rounded-full flex items-center justify-center text-3xl mb-6 border border-indigo-500/20 shadow-[0_0_50px_rgba(99,102,241,0.1)]">💎</div>
              <h4 className="text-xl font-black text-white mb-2 tracking-tighter">Analytical Core Active</h4>
              <p className="text-xs text-slate-400 font-medium max-w-[200px] leading-relaxed">Awaiting your financial inquiry for deep-dive context.</p>
            </div>
          )}
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] p-6 rounded-[28px] text-[14px] leading-relaxed font-medium shadow-lg ${
                msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-lg' : 'bg-white/5 text-slate-200 rounded-tl-lg border border-white/10'
              }`}>{msg.text}</div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white/5 border border-white/10 p-5 rounded-[24px] rounded-tl-lg flex gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" /><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.2s]" /><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.4s]" /></div>
            </div>
          )}
        </div>

        <form onSubmit={handleSend} className="p-10 border-t border-white/5 bg-black/40">
          <div className="relative">
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Query the intelligence stream..." className="w-full bg-black/40 border border-white/10 rounded-[24px] px-8 py-5 text-sm text-white font-medium focus:border-indigo-500/50 outline-none transition-all shadow-inner" />
            <button type="submit" disabled={isTyping || !input.trim()} className="absolute right-3 top-2 bottom-2 px-6 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-30 text-white rounded-xl transition-all shadow-xl shadow-indigo-900/50 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
            </button>
          </div>
        </form>
      </div>
    </>
  );
};