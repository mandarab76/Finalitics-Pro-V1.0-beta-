
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useRef, useMemo, useEffect } from 'react';
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  rectSortingStrategy,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

import { analyzeFinancialData } from './services/geminiService';
import { FinancialChart } from './components/FinancialChart';
import { TrendChart } from './components/TrendChart';
import { RiskMeter } from './components/RiskMeter';
import { ChatBot } from './components/ChatBot';
import { PeerBenchmark } from './components/PeerBenchmark';
import { ExportActions } from './components/ExportActions';
import { MatrixDetailModal } from './components/MatrixDetailModal';
import { AuditReport } from './components/AuditReport';
import { AnalysisState, AnalysisResult } from './types';

const LOGO_URL = "https://raw.githubusercontent.com/mandarab76/ATSIntegrated/main/logo.png";
const TAGLINE = "Redefining Solutions Delivery";

const TEMPLATES = [
  { name: 'Reliance Ind (Crore Input)', data: 'Revenue: ₹9.74 Trillion, PAT: ₹73,670 Crore, Debt: ₹3,13,000 Crore' },
  { name: 'TCS Ltd (Lakh Input)', data: 'Revenue: ₹2,40,893 Crore, Net Income: ₹46,585 Crore, Op Margin: 24.6%' },
  { name: 'Nvidia Corp (USD Input)', data: 'Revenue: $60.9B, Net Income: $29.7B, Cash: $25.9B' }
];

const SortableItem: React.FC<{ id: string; children: React.ReactNode; className?: string }> = ({ id, children, className }) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 50 : 'auto',
    opacity: isDragging ? 0.6 : 1,
  };

  return (
    <div ref={setNodeRef} style={style} className={`relative group/sortable ${className}`}>
      <div 
        {...attributes} 
        {...listeners} 
        className="absolute top-2 right-2 p-1.5 bg-indigo-500/80 text-white rounded-lg opacity-0 group-hover/sortable:opacity-100 transition-all cursor-grab active:cursor-grabbing z-50 shadow-lg no-print backdrop-blur-md"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="19" r="1"/></svg>
      </div>
      {children}
    </div>
  );
};

const KPIBadge = ({ label, value, unit, trend, icon, onClick }: any) => (
  <div 
    onClick={onClick}
    className="h-full glass-panel p-6 sm:p-8 rounded-[32px] hover:scale-[1.02] transition-all duration-500 group border-l-4 border-l-transparent hover:border-l-indigo-500 cursor-pointer shadow-xl"
  >
    <div className="flex justify-between items-start mb-4">
      <div className="p-3 bg-indigo-500/10 rounded-2xl text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300">
        {icon}
      </div>
      <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
        trend === 'up' ? 'bg-emerald-500/10 text-emerald-400' : trend === 'down' ? 'bg-rose-500/10 text-rose-400' : 'bg-slate-500/10 text-slate-400'
      }`}>
        {trend === 'up' ? '▲' : trend === 'down' ? '▼' : '●'} {trend}
      </div>
    </div>
    <span className="text-[10px] font-black text-amber-400 uppercase tracking-[0.2em] block mb-1">
      {label}
    </span>
    <div className="flex items-baseline gap-2 flex-wrap">
      <span className="text-3xl sm:text-4xl font-black text-white tracking-tighter">
        {typeof value === 'number' ? value.toLocaleString() : value}
      </span>
      <span className="text-xs font-bold text-indigo-400/80">{unit}</span>
    </div>
  </div>
);

export default function App() {
  const [state, setState] = useState<AnalysisState>({ buffer: "", data: null, isAnalyzing: false, error: null });
  const [hasStarted, setHasStarted] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isAuditOpen, setIsAuditOpen] = useState(false);
  const [customInput, setCustomInput] = useState("");
  const [dateRange, setDateRange] = useState({ start: '2023-01-01', end: '2024-12-31' });
  const [validationError, setValidationError] = useState<string | null>(null);
  
  // DRAG AND DROP ORDERS
  const [layoutOrder, setLayoutOrder] = useState(['metrics', 'main-charts', 'insights']);
  const [metricsOrder, setMetricsOrder] = useState<string[]>([]);
  const [chartsOrder, setChartsOrder] = useState(['trend', 'secondary', 'vector']);

  const [selectedMatrix, setSelectedMatrix] = useState<any | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 10 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  useEffect(() => {
    if (state.data) {
      const initialMetrics = state.data.metrics.map((_, i) => `metric-${i}`);
      initialMetrics.push('metric-runway');
      setMetricsOrder(initialMetrics);
    }
  }, [state.data]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const result = event.target?.result as string;
      if (result) {
        const base64Data = result.split(',')[1];
        await startAnalysis("", { data: base64Data, mimeType: file.type });
        if (fileInputRef.current) fileInputRef.current.value = "";
      }
    };
    reader.readAsDataURL(file);
  };

  const startAnalysis = async (dataToUse?: string, fileData?: { data: string, mimeType: string }) => {
    if (!dataToUse && !fileData && !customInput.trim()) {
      setValidationError("Data Source Missing: Paste statements or enter a company name.");
      setTimeout(() => setValidationError(null), 5000);
      return;
    }

    setHasStarted(true);
    setState(s => ({ ...s, isAnalyzing: true, buffer: "", data: null, error: null }));
    try {
      const result = await analyzeFinancialData(
        dataToUse || customInput, 
        (text) => setState(s => ({ ...s, buffer: text })),
        fileData,
        dateRange
      );
      setState(s => ({ ...s, isAnalyzing: false, data: result }));
    } catch (e: any) {
      setState(s => ({ ...s, isAnalyzing: false, error: { message: e.message } }));
    }
  };

  const handleDragEnd = (event: DragEndEvent, type: 'layout' | 'metrics' | 'charts') => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    if (type === 'layout') {
      setLayoutOrder((items) => arrayMove(items, items.indexOf(active.id as string), items.indexOf(over.id as string)));
    } else if (type === 'metrics') {
      setMetricsOrder((items) => arrayMove(items, items.indexOf(active.id as string), items.indexOf(over.id as string)));
    } else if (type === 'charts') {
      setChartsOrder((items) => arrayMove(items, items.indexOf(active.id as string), items.indexOf(over.id as string)));
    }
  };

  const renderSection = (id: string) => {
    const d = state.data;
    if (!d) return null;

    switch (id) {
      case 'metrics':
        return (
          <div className="space-y-6">
            <h3 className="text-xs font-black text-amber-400 uppercase tracking-[0.3em] ml-2">Intelligence Port</h3>
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={(e) => handleDragEnd(e, 'metrics')}>
              <SortableContext items={metricsOrder} strategy={rectSortingStrategy}>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
                  {metricsOrder.map((metricId) => {
                    if (metricId === 'metric-runway') {
                      return (
                        <SortableItem key={metricId} id={metricId}>
                          <KPIBadge 
                            label="Cash Runway" value={d.liquidityRunwayMonths || 0} unit="Months" trend="neutral"
                            onClick={() => setSelectedMatrix({
                              title: 'Cash Runway', value: d.liquidityRunwayMonths, unit: 'Months', category: 'Solvency Node',
                              explanation: 'Operational timeline before exhausting available liquid capital.',
                              implication: `${d.companyName} must leverage this timeline for project completion.`
                            })}
                            icon={<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>} 
                          />
                        </SortableItem>
                      );
                    }
                    const index = parseInt(metricId.split('-')[1]);
                    const m = d.metrics[index];
                    if (!m) return null;
                    return (
                      <SortableItem key={metricId} id={metricId}>
                        <KPIBadge 
                          label={m.label} 
                          value={m.value} 
                          unit={m.unit} 
                          trend={m.trend} 
                          onClick={() => setSelectedMatrix({
                            title: m.label, value: m.value, unit: m.unit, category: 'Audit Matrix Node',
                            explanation: m.description,
                            implication: `A ${m.trend} trend in ${m.label} signals a strategic pivot point for ${d.companyName}.`
                          })}
                          icon={<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>} 
                        />
                      </SortableItem>
                    );
                  })}
                </div>
              </SortableContext>
            </DndContext>
          </div>
        );
      case 'main-charts':
        return (
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={(e) => handleDragEnd(e, 'charts')}>
            <SortableContext items={chartsOrder} strategy={rectSortingStrategy}>
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 sm:gap-10">
                {chartsOrder.map((chartId) => {
                  if (chartId === 'trend') {
                    return (
                      <SortableItem key={chartId} id={chartId} className="xl:col-span-8">
                        <div className="h-[400px] sm:h-[500px]"><TrendChart trends={d.trends || []} forecasts={d.forecasts || []} /></div>
                      </SortableItem>
                    );
                  }
                  if (chartId === 'secondary') {
                    return (
                      <SortableItem key={chartId} id={chartId} className="xl:col-span-4">
                        <div className="grid grid-cols-1 gap-8 h-full">
                          <PeerBenchmark benchmarks={d.peerBenchmarking || []} />
                          <RiskMeter risks={d.riskAssessment || []} onSelect={(risk) => setSelectedMatrix({
                            title: risk.category, value: risk.score, unit: '/ 100', category: 'Risk Assessment',
                            explanation: risk.mitigation,
                            implication: `The identified ${risk.level} level threat in ${risk.category} requires immediate hedging strategy.`
                          })} />
                        </div>
                      </SortableItem>
                    );
                  }
                  if (chartId === 'vector') {
                    return (
                      <SortableItem key={chartId} id={chartId} className="xl:col-span-12">
                        <div className="glass-panel p-6 sm:p-10 rounded-[48px] flex flex-col min-h-[450px]">
                          <h3 className="text-[10px] font-black text-amber-400 uppercase tracking-[0.3em] mb-8">Intelligence Vector Analyzing</h3>
                          <div className="flex-1"><FinancialChart ratios={d.ratios || []} /></div>
                        </div>
                      </SortableItem>
                    );
                  }
                  return null;
                })}
              </div>
            </SortableContext>
          </DndContext>
        );
      case 'insights':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 sm:gap-10">
            <div className="lg:col-span-2 glass-panel p-6 sm:p-10 rounded-[48px] flex flex-col">
              <h3 className="text-sm font-black text-emerald-400 uppercase tracking-[0.2em] mb-6">Executive Context</h3>
              <p className="text-slate-400 leading-relaxed text-sm sm:text-base mb-10 font-medium flex-1">{d.summary}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                {d.insights.map((insight, i) => (
                  <div key={i} className="p-6 bg-white/5 rounded-3xl border border-white/5 text-[12px] sm:text-[13px] text-slate-300 font-semibold leading-relaxed">
                    {insight}
                  </div>
                ))}
              </div>

              {/* MICROSCOPIC SOURCE FOOTNOTE: INDUSTRY PRACTICE */}
              {d.groundingSources && d.groundingSources.length > 0 && (
                <div className="mt-auto pt-4 border-t border-white/5 opacity-20 hover:opacity-100 transition-opacity">
                   <p className="text-[7px] font-black text-slate-500 uppercase tracking-[0.4em] cursor-default select-none">Sources*</p>
                </div>
              )}
            </div>
            <div className="glass-panel p-6 sm:p-10 rounded-[48px]">
              <h3 className="text-sm font-black text-amber-400 uppercase tracking-[0.2em] mb-8">Ratio Architecture</h3>
              <div className="space-y-4">
                {d.ratios.map((r, i) => (
                  <div key={i} onClick={() => setSelectedMatrix({
                      title: r.name, value: r.value.toFixed(2), unit: 'Index', category: r.category,
                      explanation: r.interpretation, implication: `Benchmark: ${r.benchmark || 'N/A'}. This defines corporate efficiency.`
                    })} 
                    className="flex items-center justify-between p-5 bg-black/30 rounded-3xl border border-white/5 hover:border-indigo-500/30 transition-all cursor-pointer group">
                    <div className="max-w-[70%]">
                      <p className="text-[9px] font-black text-emerald-400 uppercase mb-1">{r.category}</p>
                      <p className="text-[12px] font-bold text-white truncate">{r.name}</p>
                    </div>
                    <div className="px-4 py-2 bg-indigo-500/10 text-indigo-400 rounded-2xl text-sm font-black font-mono">{r.value.toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative w-full overflow-y-auto overflow-x-hidden">
      <div className="cyber-bg" />

      {/* HEADER */}
      <header className="flex-none bg-black/40 backdrop-blur-3xl border-b border-white/5 px-6 sm:px-12 py-4 sm:h-28 flex items-center justify-between z-50 sticky top-0 no-print">
        <div className="flex items-center gap-4 sm:gap-8 overflow-hidden">
          <div className="w-12 h-12 sm:w-20 sm:h-20 bg-white rounded-xl sm:rounded-[28px] p-2 flex items-center justify-center shadow-2xl border-2 border-white/30 flex-shrink-0 relative">
             <div className="absolute inset-0 bg-white rounded-[inherit] opacity-80 blur-[2px] -z-10" />
            <img src={LOGO_URL} alt="ATSintegrated Logo" className="w-full h-full object-contain" />
          </div>
          <div className="truncate">
            <h1 className="text-xl sm:text-3xl font-black text-white tracking-tighter leading-none truncate uppercase">ATSintegrated</h1>
            <p className="text-[8px] sm:text-[10px] text-amber-400 font-black uppercase tracking-[0.4em] mt-1 sm:mt-3">{TAGLINE}</p>
          </div>
        </div>

        <div className="flex items-center gap-4 sm:gap-8 flex-shrink-0">
          <button 
            onClick={() => setIsAuditOpen(true)}
            className="hidden md:flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-white transition-all no-print"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Audit Quality
          </button>
          <button onClick={() => startAnalysis()} disabled={state.isAnalyzing} className={`px-6 sm:px-10 py-3 sm:py-5 bg-indigo-600 text-white text-[10px] sm:text-xs font-black uppercase tracking-widest rounded-xl sm:rounded-2xl transition-all active:scale-95 disabled:opacity-50 shadow-lg shadow-indigo-900/40 ${state.isAnalyzing ? 'animate-pulse' : 'hover:bg-indigo-700'}`}>
            Sync
          </button>
        </div>
      </header>

      {/* VIEWPORT CONTENT */}
      <main className="flex-1 px-6 sm:px-12 py-8 sm:py-16">
        {state.error && (
          <div className="max-w-4xl mx-auto mb-10 p-6 bg-rose-500/10 border border-rose-500/30 rounded-[32px] flex items-center gap-4 animate-in slide-in-from-top-4">
            <div className="p-3 bg-rose-500 text-white rounded-2xl flex-shrink-0"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-black text-rose-400 uppercase tracking-widest">System Anomaly</p>
              <p className="text-xs text-rose-300 font-medium mt-1 truncate">{state.error.message}</p>
            </div>
            <button onClick={() => setState(s => ({ ...s, error: null }))} className="text-rose-400 hover:text-white"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
          </div>
        )}

        {!hasStarted ? (
          <div className="max-w-5xl mx-auto py-12 sm:py-24 text-center">
            <span className="inline-block px-5 py-2 bg-indigo-500/10 text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-[0.4em] mb-8 border border-indigo-500/20">Alpha Intelligence Platform</span>
            <h2 className="text-4xl sm:text-8xl font-black text-white tracking-tighter mb-10 leading-tight">
              Enterprise Financial <br/> <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-indigo-400">Decision Port.</span>
            </h2>
            
            <div className="glass-panel p-6 sm:p-12 rounded-[48px] sm:rounded-[64px] text-left max-w-4xl mx-auto border border-white/10 shadow-2xl relative overflow-hidden">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
                <div className="flex items-center gap-4">
                  <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-900/40"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg></div>
                  <div>
                    <h3 className="text-xl font-black text-white leading-none uppercase tracking-tighter">Intelligence Port</h3>
                    <p className="text-[10px] font-black text-amber-400 uppercase tracking-widest mt-2">(Amounts are auto-normalized to nearest ₹ Million)</p>
                  </div>
                </div>
                <div className="flex gap-3">
                   <button onClick={() => fileInputRef.current?.click()} className="px-5 py-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20 text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all">Upload</button>
                   <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".pdf,image/*" />
                </div>
              </div>
              
              <textarea 
                value={customInput} onChange={(e) => setCustomInput(e.target.value)} 
                placeholder="Paste ledger strings, raw P&L data, or enter NSE ticker (e.g. RELIANCE)..." 
                className="w-full h-48 sm:h-72 bg-black/40 border border-white/5 rounded-[32px] p-6 sm:p-10 text-sm sm:text-base text-slate-300 focus:border-indigo-500 outline-none transition-all resize-none mb-10 shadow-inner" 
              />
              
              <button onClick={() => startAnalysis()} className="w-full py-6 sm:py-8 bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase tracking-[0.3em] rounded-[32px] transition-all text-xs sm:text-sm shadow-2xl shadow-indigo-900/30 hover:scale-[1.01]">Initialize Analysis Engine</button>
              
              {validationError && <p className="mt-6 text-center text-rose-400 text-[10px] font-black uppercase tracking-widest animate-pulse">{validationError}</p>}
            </div>
            
            <div className="mt-12 flex flex-wrap justify-center gap-4">
               {TEMPLATES.map((t, i) => (
                 <button key={i} onClick={() => { setCustomInput(t.data); startAnalysis(t.data); }} className="px-5 py-3 bg-white/5 border border-white/10 rounded-2xl text-[9px] font-black text-slate-400 uppercase tracking-widest hover:text-white hover:border-amber-400 transition-all">
                    {t.name}
                 </button>
               ))}
            </div>
          </div>
        ) : (
          <div className="max-w-[1700px] mx-auto space-y-12 sm:space-y-16 pb-32">
            {state.isAnalyzing && (
              <div className="flex flex-col items-center justify-center py-24 animate-in fade-in duration-700">
                <div className="relative w-36 h-36 sm:w-48 sm:h-48 flex items-center justify-center mb-14">
                  <div className="absolute inset-0 border-[0.5px] border-amber-500/20 rounded-full animate-ping" />
                  <svg className="absolute w-full h-full animate-[spin_8s_linear_infinite]" viewBox="0 0 100 100"><circle cx="50" cy="5" r="4" fill="#fbbf24" className="shadow-[0_0_20px_#fbbf24]" /></svg>
                  <svg className="absolute w-[80%] h-[80%] animate-[spin_4s_linear_infinite_reverse]" viewBox="0 0 100 100"><circle cx="95" cy="50" r="5" fill="#10b981" /></svg>
                  <span className="text-6xl sm:text-8xl font-black text-white drop-shadow-[0_0_40px_rgba(251,191,36,0.8)] select-none">₹</span>
                </div>
              </div>
            )}

            {!state.isAnalyzing && state.data && (
              <>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 no-print bg-white/5 p-8 rounded-[40px] border border-white/10 shadow-2xl backdrop-blur-xl">
                  <div className="flex items-center gap-6 overflow-hidden">
                     <div className="w-16 h-16 bg-white rounded-3xl flex items-center justify-center p-2 shadow-2xl shadow-black/50 flex-shrink-0 border border-white/10 relative">
                        <div className="absolute inset-0 bg-white rounded-[inherit] opacity-80 blur-[1px] -z-10" />
                       <img src={LOGO_URL} alt="Brand" className="w-full h-full object-contain" />
                     </div>
                     <div className="truncate">
                       <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tighter leading-none truncate uppercase">{state.data.companyName}</h2>
                       <div className="flex items-center gap-4 mt-3">
                         <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 text-[9px] font-black rounded-lg border border-emerald-500/20 uppercase tracking-widest">Context Active</span>
                         <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Analysis Horizon: {dateRange.start.split('-')[0]} - {dateRange.end.split('-')[0]}</p>
                       </div>
                     </div>
                  </div>
                  <ExportActions data={state.data} />
                </div>

                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={(e) => handleDragEnd(e, 'layout')}>
                  <SortableContext items={layoutOrder} strategy={verticalListSortingStrategy}>
                    <div className="space-y-12 sm:space-y-20">
                      {layoutOrder.map((id) => (
                        <SortableItem key={id} id={id}>
                          {renderSection(id)}
                        </SortableItem>
                      ))}
                    </div>
                  </SortableContext>
                </DndContext>
              </>
            )}
          </div>
        )}
      </main>

      <ChatBot isOpen={isChatOpen} onClose={() => setIsChatOpen(!isChatOpen)} context={JSON.stringify(state.data)} />
      <MatrixDetailModal detail={selectedMatrix} onClose={() => setSelectedMatrix(null)} />
      <AuditReport isOpen={isAuditOpen} onClose={() => setIsAuditOpen(false)} />

      <footer className="py-20 sm:py-28 border-t border-white/5 bg-black/80 px-6 sm:px-12 no-print mt-auto">
        <div className="max-w-4xl mx-auto text-center space-y-10">
          <div className="flex flex-wrap items-center justify-center gap-8 text-[11px] font-black text-slate-400">
             <span className="flex items-center gap-3 px-5 py-2.5 bg-white/5 rounded-full border border-white/10 shadow-lg">
               <div className={`w-2.5 h-2.5 rounded-full ${state.isAnalyzing ? 'bg-amber-400 animate-pulse' : 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]'}`} />
               {state.isAnalyzing ? 'Analyzing streams...' : 'Precision Core Nominal'}
             </span>
             <span className="flex items-center gap-2.5">
               <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-amber-400"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
               Institutional Security AES-256
             </span>
             <span className="font-mono text-emerald-400/70 uppercase text-[9px] tracking-[0.2em] font-black">FinEngine Pro v4.9.5-Alpha</span>
          </div>
          <div className="pt-8 border-t border-white/5">
            <p className="text-lg sm:text-xl font-black text-white tracking-tight leading-relaxed uppercase">
              Developed by <span className="text-amber-400 border-b-2 border-amber-500/30 px-1">Mandar Bahadarpurkar</span> for ATSintegrated
            </p>
            <p className="text-[11px] text-slate-500 mt-5 tracking-[0.6em] uppercase font-black opacity-60">{TAGLINE}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
