
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export interface FinancialMetric {
  label: string;
  value: number;
  unit: string;
  trend: 'up' | 'down' | 'neutral';
  description: string;
}

export interface FinancialRatio {
  category: 'Liquidity' | 'Profitability' | 'Solvency' | 'Efficiency';
  name: string;
  value: number;
  formula: string;
  interpretation: string;
  benchmark?: string;
}

export interface TrendData {
  period: string;
  revenue: number;
  expenses: number;
  margin: number;
}

export interface RiskFactor {
  category: string;
  level: 'low' | 'medium' | 'high';
  score: number;
  mitigation: string;
}

export interface ForecastPoint {
  period: string;
  projected: number;
  confidence: [number, number];
}

export interface PeerBenchmark {
  metric: string;
  companyValue: number;
  industryAverage: number;
}

export interface AnalysisResult {
  companyName: string;
  summary: string;
  metrics: FinancialMetric[];
  ratios: FinancialRatio[];
  insights: string[];
  rawFormulas: string;
  trends: TrendData[];
  riskAssessment: RiskFactor[];
  forecasts: ForecastPoint[];
  peerBenchmarking: PeerBenchmark[];
  liquidityRunwayMonths: number;
  // Added to store grounding metadata from Search tool
  groundingSources?: Array<{ title: string; uri: string }>;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface AnalysisState {
  buffer: string;
  data: AnalysisResult | null;
  isAnalyzing: boolean;
  error: {
    message: string;
    code?: string;
    details?: string;
  } | null;
}

export interface SpinnerData {
  id?: string | number;
  mutationName: string;
  reasoning: string;
  p5Code: string;
  totalTokens?: number;
  generationTimeMs?: number;
  tokensPerSecond?: number | string;
  tpsHistory: number[];
}

export interface CandidateState {
  data: SpinnerData | null;
  buffer: string;
  tpsHistory: number[];
}
